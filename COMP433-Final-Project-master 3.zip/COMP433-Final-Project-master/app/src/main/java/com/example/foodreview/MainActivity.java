package com.example.foodreview;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int num_stars = 0;
    String mealz = null;
    String prices = null;
    String food_type = null;
    Bitmap current = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void thrillz(View view) {
        setContentView(R.layout.thrillz);
    }

    public void back(View view) {
        setContentView(R.layout.activity_main);
    }

    public void food(View view) {
        setContentView(R.layout.mealz);
    }

    public void lifestyle(View view) {
        setContentView(R.layout.l_style);
    }

    public void entertainment(View view) {
        setContentView(R.layout.fun);
    }

    public void menu_back(View view) {
        setContentView(R.layout.thrillz);
    }

    public void food_results(View view) {
        setContentView(R.layout.top_food);
    }

    public void l_back(View view) {
        setContentView(R.layout.thrillz);
    }

    public void life_results(View view) {
        setContentView(R.layout.top_life);
    }

    public void e_back(View view) {
        setContentView(R.layout.thrillz);
    }

    public void fun_results(View view) {
        setContentView(R.layout.top_fun);
    }

    public void food_r_back(View view) {
        setContentView(R.layout.mealz);
    }

    public void adv_food(View view) {
        setContentView(R.layout.adv_food_search);
    }

    public void adv_food_back(View view) {
        setContentView(R.layout.top_food);
    }

    public void life_r_back(View view) {
        setContentView(R.layout.l_style);
    }

    public void adv_life(View view) {
        setContentView(R.layout.adv_life_search);
    }

    public void adv_life_back(View view) {
        setContentView(R.layout.top_life);
    }

    public void fun_r_back(View view) {
        setContentView(R.layout.fun);
    }

    public void adv_fun(View view) {
        setContentView(R.layout.adv_fun_search);
    }

    public void adv_fun_back(View view) {
        setContentView(R.layout.top_fun);
    }

    public void review(View view) {
        setContentView(R.layout.reviews_homepage);
    }

    public void back_home(View view) {
        setContentView(R.layout.activity_main);
    }

    public void food_review(View view) {
        setContentView(R.layout.food_review);
    }

    public void lifestyle_review(View view) {
        setContentView(R.layout.lifestyle_review);
    }

    public void entertainment_review(View view) {
        setContentView(R.layout.entertainment_review);
    }

    public void food_review_back(View view) {
        setContentView(R.layout.reviews_homepage);
    }

    public void lifestyle_review_back(View view) {
        setContentView(R.layout.reviews_homepage);
    }

    public void entertainment_review_back(View view) {
        setContentView(R.layout.reviews_homepage);
    }

    public void food_submit(View view) {
        Context context = getApplicationContext();
        EditText restaurant = findViewById(R.id.restaurant);
        EditText address = findViewById(R.id.address);
        if (restaurant.length() == 0) {
            Toast no_restaurant = Toast.makeText(context, "No Restaurant Name Specified", Toast.LENGTH_LONG);
            no_restaurant.show();
        } else if (address.length() == 0) {
            Toast no_address = Toast.makeText(context, "No Address Specified", Toast.LENGTH_LONG);
            no_address.show();
        } else {
            setContentView(R.layout.top_food);
            ImageView resto_pic = findViewById(R.id.r_one_pic);
            TextView name = findViewById(R.id.restaurant_one);
            TextView home = findViewById(R.id.address_one);
            TextView rating = findViewById(R.id.rating_one);
            TextView meal = findViewById(R.id.meal_one);
            TextView price = findViewById(R.id.price_one);
            TextView cuisine = findViewById(R.id.cuisine_one);
            name.setText(restaurant.getText());
            home.setText(address.getText());
            rating.setText("Rating:" + num_stars);
            meal.setText(mealz);
            price.setText(prices);
            cuisine.setText(food_type);
            resto_pic.setImageBitmap(current);

            num_stars = 0;
            mealz = null;
            prices = null;
            food_type = null;
            Toast saved = Toast.makeText(context, "Review Has Been Saved", Toast.LENGTH_LONG);
            saved.show();



        }
    }

    public void food_yellow_star(View view) {
        if (view.getTag().toString() != "yellow") {
            view.setBackgroundResource(R.drawable.yellow_star);
            view.setTag("yellow");
            num_stars = num_stars + 1;
            Log.v("FOCUS", num_stars + "");

        } else if (view.getTag().toString() == "yellow") {
            view.setBackgroundResource(R.drawable.star);
            view.setTag("white");
            num_stars = num_stars - 1;
            Log.v("FOCUS", num_stars + "");

        }


    }

    public void lifestyle_yellow_star(View view) {
        if (view.getTag().toString() != "yellow") {
            view.setBackgroundResource(R.drawable.yellow_star);
            view.setTag("yellow");
            num_stars = num_stars + 1;
            Log.v("FOCUS", num_stars + "");
        } else if (view.getTag().toString() == "yellow") {
            view.setBackgroundResource(R.drawable.star);
            view.setTag("white");
            num_stars = num_stars - 1;
            Log.v("FOCUS", num_stars + "");

        }

    }

    public void fun_yellow_star(View view) {
        if (view.getTag().toString() != "yellow") {
            view.setBackgroundResource(R.drawable.yellow_star);
            view.setTag("yellow");
            num_stars = num_stars + 1;
        } else if (view.getTag().toString() == "yellow") {
            view.setBackgroundResource(R.drawable.star);
            view.setTag("white");
            num_stars = num_stars - 1;

        }

    }

    public void food_green_dot(View view) {
        Log.v("FOCUS", view.isFocusable() + "");
        // switch if statements back to tags
        if (view.isFocusable() == true) {
            view.setBackgroundResource(R.drawable.green_dot);
            view.setFocusable(false);
            if (view.getTag().toString().contains("Meal")) {
                mealz = view.getTag().toString();
            } else if (view.getTag().toString().contains("Price")) {
                prices = view.getTag().toString();
            } else if (view.getTag().toString().contains("Cuisine")) {
                food_type = view.getTag().toString();
            }
            Log.v("FOCUS", mealz + "");
        } else if (view.isFocusable() == false) {
            view.setBackgroundResource(R.drawable.circle);
            view.setFocusable(true);
            if (view.getTag().toString().contains("Meal")) {
                mealz = null;
            } else if (view.getTag().toString().contains("Price")) {
                prices = null;
            } else if (view.getTag().toString().contains("Cuisine")) {
                food_type = null;
            }


        }

    }

    public void lifestyle_green_dot(View view) {
        if (view.getBackground().getCurrent().equals(getDrawable(R.drawable.circle))) {
            view.setBackgroundResource(R.drawable.green_dot);
        } else if (view.getBackground().getCurrent().equals(getDrawable(R.drawable.green_dot))) {
            view.setBackgroundResource(R.drawable.circle);

        }

    }

    public void fun__green_dot(View view) {
        if (view.getBackground().getCurrent().equals(getDrawable(R.drawable.circle))) {
            view.setBackgroundResource(R.drawable.green_dot);
        } else if (view.getBackground().getCurrent().equals(getDrawable(R.drawable.green_dot))) {
            view.setBackgroundResource(R.drawable.circle);

        }

    }

    public void food_photo(View view) {
        Intent x = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(x,1);

    }

    protected void onActivityResult(int rc, int resc, Intent data) {
        ImageView image = null;
        Bitmap bitmap = (Bitmap) data.getExtras().get("data");
        image = (ImageView) findViewById(R.id.food_pic);
        image.setBackgroundResource(0);
        image.setImageBitmap(bitmap);
        current = bitmap;

    }
}

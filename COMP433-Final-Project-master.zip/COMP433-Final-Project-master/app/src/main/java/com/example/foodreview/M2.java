package com.example.foodreview;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class M2 extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.thrillz);
    }

    public void back(View view) {
        Intent x = new Intent(this, MainActivity.class);
        startActivity(x);
    }

    public void food(View view) {
        Intent y = new Intent(this, Food.class);
        startActivity(y);
    }

    public void lifestyle(View view) {
        Intent z = new Intent(this, Lifestyle.class);
        startActivity(z);
    }

    public void entertainment(View view) {
        Intent a = new Intent(this, Entertainment.class);
        startActivity(a);
    }
}

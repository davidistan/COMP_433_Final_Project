package com.example.foodreview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void thrillz(View view) {
        Intent x = new Intent(this, M2.class);
        startActivity(x);
    }

    public void review(View view) {
        setContentView(R.layout.reviews_homepage);
    }

    public void back_home(View view) {
        setContentView(R.layout.activity_main);
    }


}

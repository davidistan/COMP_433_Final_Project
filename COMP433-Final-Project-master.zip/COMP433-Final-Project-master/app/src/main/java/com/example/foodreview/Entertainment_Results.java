package com.example.foodreview;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class Entertainment_Results extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.top_fun);
    }

    public void fun_r_back(View view) {
        Intent x = new Intent(this, Entertainment.class);
        startActivity(x);
    }

    public void adv_fun(View view) {
        setContentView(R.layout.adv_fun_search);
    }

    public void adv_fun_back(View view) {
        setContentView(R.layout.top_fun);
    }
}

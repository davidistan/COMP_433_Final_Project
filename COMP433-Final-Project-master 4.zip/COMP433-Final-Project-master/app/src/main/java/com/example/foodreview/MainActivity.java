package com.example.foodreview;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class MainActivity extends AppCompatActivity {
    int num_stars = 0;
    int service_stars = 0;
    String mealz = null;
    String prices = null;
    String category = null;
    String lifestyle_price = null;
    String food_type = null;
    Bitmap current = null;
    boolean food_pic = false;
    boolean lifestyle_pic = false;
    boolean fun_pic = false;
    SQLiteDatabase database_reviews = null;
    Cursor main_cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        database_reviews = openOrCreateDatabase("DB", Context.MODE_PRIVATE, null);
        database_setup();
    }

    public void database_setup() {
        database_reviews.execSQL("drop table if exists Food");
        database_reviews.execSQL("drop table if exists Lifestyle");
        database_reviews.execSQL("drop table if exists Entertainment");
        database_reviews.execSQL("create table Food(Name text, Address text, Rating int, Meal text, Price text, Cuisine text, Photo blob)");
        database_reviews.execSQL("create table Lifestyle(Name text, Address text, Rating int, Category text, Price text, Service int, Photo blob)");

    }

    public void thrillz(View view) {
        setContentView(R.layout.thrillz);
    }

    public void back(View view) {
        setContentView(R.layout.activity_main);
    }

    public void food(View view) {
        setContentView(R.layout.mealz);
    }

    public void lifestyle(View view) {
        setContentView(R.layout.l_style);
    }

    public void entertainment(View view) {
        setContentView(R.layout.fun);
    }

    public void menu_back(View view) {
        setContentView(R.layout.thrillz);
    }

    public void food_results(View view) {
        setContentView(R.layout.top_food);
    }

    public void breakfast_results(View view) {
        Log.v("BREAKFAST", "IT'S BREAKFAST TIME");
        setContentView(R.layout.top_food);
        TextView name = findViewById(R.id.restaurant_one);
        TextView home = findViewById(R.id.address_one);
        TextView rating = findViewById(R.id.rating_one);
        TextView meal = findViewById(R.id.meal_one);
        TextView price = findViewById(R.id.price_one);
        TextView cuisine = findViewById(R.id.cuisine_one);
        ImageView foto = findViewById(R.id.r_one_pic);
        ImageView second_foto = findViewById(R.id.r_two_pic);
        ImageView third_foto = findViewById(R.id.r_three_pic);
        String breakfast = "Meal:Breakfast";
        String b_results = "select * from Food F where F.Meal = " + "'" + breakfast + "'" + "order by F.Rating desc;";
        main_cursor = database_reviews.rawQuery(b_results, null);
        if (main_cursor.getCount() > 0) {
            main_cursor.moveToFirst();
            name.setText(main_cursor.getString(0));
            home.setText(main_cursor.getString(1));
            rating.setText("Rating:" + main_cursor.getInt(2));
            meal.setText(main_cursor.getString(3));
            price.setText(main_cursor.getString(4));
            cuisine.setText(main_cursor.getString(5));
            byte[] b_photo = main_cursor.getBlob(6);
            Bitmap picture = BitmapFactory.decodeByteArray(b_photo, 0, b_photo.length);
            foto.setBackgroundResource(0);
            foto.setImageBitmap(picture);
            if (main_cursor.moveToNext() == true) {
                TextView second_name = findViewById(R.id.restaurant_two);
                TextView second_home = findViewById(R.id.address_two);
                TextView second_rating = findViewById(R.id.rating_two);
                TextView second_meal = findViewById(R.id.meal_two);
                TextView second_price = findViewById(R.id.price_two);
                TextView second_cuisine = findViewById(R.id.cuisine_two);
                second_name.setText(main_cursor.getString(0));
                second_home.setText(main_cursor.getString(1));
                second_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                second_meal.setText(main_cursor.getString(3));
                second_price.setText(main_cursor.getString(4));
                second_cuisine.setText(main_cursor.getString(5));
                byte[] second_b_photo = main_cursor.getBlob(6);
                Bitmap second_picture = BitmapFactory.decodeByteArray(second_b_photo, 0, second_b_photo.length);
                second_foto.setBackgroundResource(0);
                second_foto.setImageBitmap(second_picture);
                if (main_cursor.moveToNext() == true) {
                    TextView third_name = findViewById(R.id.restaurant_three);
                    TextView third_home = findViewById(R.id.address_three);
                    TextView third_rating = findViewById(R.id.rating_three);
                    TextView third_meal = findViewById(R.id.meal_three);
                    TextView third_price = findViewById(R.id.price_three);
                    TextView third_cuisine = findViewById(R.id.cuisine_three);
                    third_name.setText(main_cursor.getString(0));
                    third_home.setText(main_cursor.getString(1));
                    third_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                    third_meal.setText(main_cursor.getString(3));
                    third_price.setText(main_cursor.getString(4));
                    third_cuisine.setText(main_cursor.getString(5));
                    byte[] third_b_photo = main_cursor.getBlob(6);
                    Bitmap third_picture = BitmapFactory.decodeByteArray(third_b_photo, 0, third_b_photo.length);
                    third_foto.setBackgroundResource(0);
                    third_foto.setImageBitmap(third_picture);


                }
            }
        }

    }

    public void lunch_results(View view) {
        Log.v("LUNCH", "IT'S LUNCHTIME");
        setContentView(R.layout.top_food);
        TextView name = findViewById(R.id.restaurant_one);
        TextView home = findViewById(R.id.address_one);
        TextView rating = findViewById(R.id.rating_one);
        TextView meal = findViewById(R.id.meal_one);
        TextView price = findViewById(R.id.price_one);
        TextView cuisine = findViewById(R.id.cuisine_one);
        ImageView foto = findViewById(R.id.r_one_pic);
        ImageView second_foto = findViewById(R.id.r_two_pic);
        ImageView third_foto = findViewById(R.id.r_three_pic);
        String lunch = "Meal:Lunch";
        String b_results = "select * from Food F where F.Meal = " + "'" + lunch + "'" + "order by F.Rating desc;";
        main_cursor = database_reviews.rawQuery(b_results, null);
        if (main_cursor.getCount() > 0) {
            main_cursor.moveToFirst();
            name.setText(main_cursor.getString(0));
            home.setText(main_cursor.getString(1));
            rating.setText("Rating:" + main_cursor.getInt(2));
            meal.setText(main_cursor.getString(3));
            price.setText(main_cursor.getString(4));
            cuisine.setText(main_cursor.getString(5));
            byte[] b_photo = main_cursor.getBlob(6);
            Bitmap picture = BitmapFactory.decodeByteArray(b_photo, 0, b_photo.length);
            foto.setBackgroundResource(0);
            foto.setImageBitmap(picture);
            if (main_cursor.moveToNext() == true) {
                TextView second_name = findViewById(R.id.restaurant_two);
                TextView second_home = findViewById(R.id.address_two);
                TextView second_rating = findViewById(R.id.rating_two);
                TextView second_meal = findViewById(R.id.meal_two);
                TextView second_price = findViewById(R.id.price_two);
                TextView second_cuisine = findViewById(R.id.cuisine_two);
                second_name.setText(main_cursor.getString(0));
                second_home.setText(main_cursor.getString(1));
                second_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                second_meal.setText(main_cursor.getString(3));
                second_price.setText(main_cursor.getString(4));
                second_cuisine.setText(main_cursor.getString(5));
                byte[] second_b_photo = main_cursor.getBlob(6);
                Bitmap second_picture = BitmapFactory.decodeByteArray(second_b_photo, 0, second_b_photo.length);
                second_foto.setBackgroundResource(0);
                second_foto.setImageBitmap(second_picture);
                if (main_cursor.moveToNext() == true) {
                    TextView third_name = findViewById(R.id.restaurant_three);
                    TextView third_home = findViewById(R.id.address_three);
                    TextView third_rating = findViewById(R.id.rating_three);
                    TextView third_meal = findViewById(R.id.meal_three);
                    TextView third_price = findViewById(R.id.price_three);
                    TextView third_cuisine = findViewById(R.id.cuisine_three);
                    third_name.setText(main_cursor.getString(0));
                    third_home.setText(main_cursor.getString(1));
                    third_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                    third_meal.setText(main_cursor.getString(3));
                    third_price.setText(main_cursor.getString(4));
                    third_cuisine.setText(main_cursor.getString(5));
                    byte[] third_b_photo = main_cursor.getBlob(6);
                    Bitmap third_picture = BitmapFactory.decodeByteArray(third_b_photo, 0, third_b_photo.length);
                    third_foto.setBackgroundResource(0);
                    third_foto.setImageBitmap(third_picture);


                }
            }
        }

    }

    public void dinner_results(View view) {
        Log.v("DINNER", "IT'S DINNER TIME");
        setContentView(R.layout.top_food);
        TextView name = findViewById(R.id.restaurant_one);
        TextView home = findViewById(R.id.address_one);
        TextView rating = findViewById(R.id.rating_one);
        TextView meal = findViewById(R.id.meal_one);
        TextView price = findViewById(R.id.price_one);
        TextView cuisine = findViewById(R.id.cuisine_one);
        ImageView foto = findViewById(R.id.r_one_pic);
        ImageView second_foto = findViewById(R.id.r_two_pic);
        ImageView third_foto = findViewById(R.id.r_three_pic);
        String dinner = "Meal:Dinner";
        String b_results = "select * from Food F where F.Meal = " + "'" + dinner + "'" + "order by F.Rating desc;";
        main_cursor = database_reviews.rawQuery(b_results, null);
        if (main_cursor.getCount() > 0) {
            main_cursor.moveToFirst();
            name.setText(main_cursor.getString(0));
            home.setText(main_cursor.getString(1));
            rating.setText("Rating:" + main_cursor.getInt(2));
            meal.setText(main_cursor.getString(3));
            price.setText(main_cursor.getString(4));
            cuisine.setText(main_cursor.getString(5));
            byte[] b_photo = main_cursor.getBlob(6);
            Bitmap picture = BitmapFactory.decodeByteArray(b_photo, 0, b_photo.length);
            foto.setBackgroundResource(0);
            foto.setImageBitmap(picture);
            if (main_cursor.moveToNext() == true) {
                TextView second_name = findViewById(R.id.restaurant_two);
                TextView second_home = findViewById(R.id.address_two);
                TextView second_rating = findViewById(R.id.rating_two);
                TextView second_meal = findViewById(R.id.meal_two);
                TextView second_price = findViewById(R.id.price_two);
                TextView second_cuisine = findViewById(R.id.cuisine_two);
                second_name.setText(main_cursor.getString(0));
                second_home.setText(main_cursor.getString(1));
                second_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                second_meal.setText(main_cursor.getString(3));
                second_price.setText(main_cursor.getString(4));
                second_cuisine.setText(main_cursor.getString(5));
                byte[] second_b_photo = main_cursor.getBlob(6);
                Bitmap second_picture = BitmapFactory.decodeByteArray(second_b_photo, 0, second_b_photo.length);
                second_foto.setBackgroundResource(0);
                second_foto.setImageBitmap(second_picture);
                if (main_cursor.moveToNext() == true) {
                    TextView third_name = findViewById(R.id.restaurant_three);
                    TextView third_home = findViewById(R.id.address_three);
                    TextView third_rating = findViewById(R.id.rating_three);
                    TextView third_meal = findViewById(R.id.meal_three);
                    TextView third_price = findViewById(R.id.price_three);
                    TextView third_cuisine = findViewById(R.id.cuisine_three);
                    third_name.setText(main_cursor.getString(0));
                    third_home.setText(main_cursor.getString(1));
                    third_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                    third_meal.setText(main_cursor.getString(3));
                    third_price.setText(main_cursor.getString(4));
                    third_cuisine.setText(main_cursor.getString(5));
                    byte[] third_b_photo = main_cursor.getBlob(6);
                    Bitmap third_picture = BitmapFactory.decodeByteArray(third_b_photo, 0, third_b_photo.length);
                    third_foto.setBackgroundResource(0);
                    third_foto.setImageBitmap(third_picture);


                }
            }
        }

    }

    public void all_food_results(View view) {
        Log.v("ALL RESULTS", "ALL RESULTS");
        setContentView(R.layout.top_food);
        TextView name = findViewById(R.id.restaurant_one);
        TextView home = findViewById(R.id.address_one);
        TextView rating = findViewById(R.id.rating_one);
        TextView meal = findViewById(R.id.meal_one);
        TextView price = findViewById(R.id.price_one);
        TextView cuisine = findViewById(R.id.cuisine_one);
        ImageView foto = findViewById(R.id.r_one_pic);
        ImageView second_foto = findViewById(R.id.r_two_pic);
        ImageView third_foto = findViewById(R.id.r_three_pic);
        String b_results = "select * from Food F order by F.Rating desc;";
        main_cursor = database_reviews.rawQuery(b_results, null);
        Log.v("COUNT", main_cursor.getCount() + "");
        if (main_cursor.getCount() > 0) {
            main_cursor.moveToFirst();
            name.setText(main_cursor.getString(0));
            home.setText(main_cursor.getString(1));
            rating.setText("Rating:" + main_cursor.getInt(2));
            meal.setText(main_cursor.getString(3));
            price.setText(main_cursor.getString(4));
            cuisine.setText(main_cursor.getString(5));
            byte[] b_photo = main_cursor.getBlob(6);
            Bitmap picture = BitmapFactory.decodeByteArray(b_photo, 0, b_photo.length);
            foto.setBackgroundResource(0);
            foto.setImageBitmap(picture);
            if (main_cursor.moveToNext() == true) {
                TextView second_name = findViewById(R.id.restaurant_two);
                TextView second_home = findViewById(R.id.address_two);
                TextView second_rating = findViewById(R.id.rating_two);
                TextView second_meal = findViewById(R.id.meal_two);
                TextView second_price = findViewById(R.id.price_two);
                TextView second_cuisine = findViewById(R.id.cuisine_two);
                second_name.setText(main_cursor.getString(0));
                second_home.setText(main_cursor.getString(1));
                second_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                second_meal.setText(main_cursor.getString(3));
                second_price.setText(main_cursor.getString(4));
                second_cuisine.setText(main_cursor.getString(5));
                byte[] second_b_photo = main_cursor.getBlob(6);
                Bitmap second_picture = BitmapFactory.decodeByteArray(second_b_photo, 0, second_b_photo.length);
                second_foto.setBackgroundResource(0);
                second_foto.setImageBitmap(second_picture);
                if (main_cursor.moveToNext() == true) {
                    TextView third_name = findViewById(R.id.restaurant_three);
                    TextView third_home = findViewById(R.id.address_three);
                    TextView third_rating = findViewById(R.id.rating_three);
                    TextView third_meal = findViewById(R.id.meal_three);
                    TextView third_price = findViewById(R.id.price_three);
                    TextView third_cuisine = findViewById(R.id.cuisine_three);
                    third_name.setText(main_cursor.getString(0));
                    third_home.setText(main_cursor.getString(1));
                    third_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                    third_meal.setText(main_cursor.getString(3));
                    third_price.setText(main_cursor.getString(4));
                    third_cuisine.setText(main_cursor.getString(5));
                    byte[] third_b_photo = main_cursor.getBlob(6);
                    Bitmap third_picture = BitmapFactory.decodeByteArray(third_b_photo, 0, third_b_photo.length);
                    third_foto.setBackgroundResource(0);
                    third_foto.setImageBitmap(third_picture);


                }
            }
        }

    }

    public void grocery_results(View view) {
        Log.v("LIFESTYLE", "GROCERIES");
        setContentView(R.layout.top_life);
        TextView name = findViewById(R.id.life_name_one);
        TextView home = findViewById(R.id.life_address_one);
        TextView rating = findViewById(R.id.life_rating_one);
        TextView category = findViewById(R.id.life_category_one);
        TextView price = findViewById(R.id.life_price_one);
        TextView service = findViewById(R.id.life_service_one);
        ImageView foto = findViewById(R.id.life_one_pic);
        ImageView second_foto = findViewById(R.id.life_two_pic);
        ImageView third_foto = findViewById(R.id.life_three_pic);
        String grocery = "Category:Groceries";
        String grocery_result = "select * from Lifestyle L where L.Category = " + "'" + grocery + "'" + "order by L.Rating desc;";
        main_cursor = database_reviews.rawQuery(grocery_result, null);
        if (main_cursor.getCount() > 0) {
            main_cursor.moveToFirst();
            name.setText(main_cursor.getString(0));
            home.setText(main_cursor.getString(1));
            rating.setText("Rating:" + main_cursor.getInt(2));
            category.setText(main_cursor.getString(3));
            price.setText(main_cursor.getString(4));
            service.setText(main_cursor.getString(5));
            byte[] b_photo = main_cursor.getBlob(6);
            Bitmap picture = BitmapFactory.decodeByteArray(b_photo, 0, b_photo.length);
            foto.setBackgroundResource(0);
            foto.setImageBitmap(picture);
            if (main_cursor.moveToNext() == true) {
                TextView second_name = findViewById(R.id.life_name_two);
                TextView second_home = findViewById(R.id.life_address_two);
                TextView second_rating = findViewById(R.id.life_rating_two);
                TextView second_category = findViewById(R.id.life_category_two);
                TextView second_price = findViewById(R.id.life_price_two);
                TextView second_service = findViewById(R.id.life_service_two);
                second_name.setText(main_cursor.getString(0));
                second_home.setText(main_cursor.getString(1));
                second_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                second_category.setText(main_cursor.getString(3));
                second_price.setText(main_cursor.getString(4));
                second_service.setText("Service:" + main_cursor.getString(5));
                byte[] second_b_photo = main_cursor.getBlob(6);
                Bitmap second_picture = BitmapFactory.decodeByteArray(second_b_photo, 0, second_b_photo.length);
                second_foto.setBackgroundResource(0);
                second_foto.setImageBitmap(second_picture);
                if (main_cursor.moveToNext() == true) {
                    TextView third_name = findViewById(R.id.life_name_three);
                    TextView third_home = findViewById(R.id.life_address_three);
                    TextView third_rating = findViewById(R.id.life_rating_three);
                    TextView third_category = findViewById(R.id.life_category_three);
                    TextView third_price = findViewById(R.id.life_price_three);
                    TextView third_service = findViewById(R.id.life_service_three);
                    third_name.setText(main_cursor.getString(0));
                    third_home.setText(main_cursor.getString(1));
                    third_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                    third_category.setText(main_cursor.getString(3));
                    third_price.setText(main_cursor.getString(4));
                    third_service.setText(main_cursor.getString(5));
                    byte[] third_b_photo = main_cursor.getBlob(6);
                    Bitmap third_picture = BitmapFactory.decodeByteArray(third_b_photo, 0, third_b_photo.length);
                    third_foto.setBackgroundResource(0);
                    third_foto.setImageBitmap(third_picture);


                }
            }
        }

    }

    public void gas_results(View view) {
        Log.v("LIFESTYLE", "GROCERIES");
        setContentView(R.layout.top_life);
        TextView name = findViewById(R.id.life_name_one);
        TextView home = findViewById(R.id.life_address_one);
        TextView rating = findViewById(R.id.life_rating_one);
        TextView category = findViewById(R.id.life_category_one);
        TextView price = findViewById(R.id.life_price_one);
        TextView service = findViewById(R.id.life_service_one);
        ImageView foto = findViewById(R.id.life_one_pic);
        ImageView second_foto = findViewById(R.id.life_two_pic);
        ImageView third_foto = findViewById(R.id.life_three_pic);
        String gas = "Category:Gas";
        String grocery_result = "select * from Lifestyle L where L.Category = " + "'" + gas + "'" + "order by L.Rating desc;";
        main_cursor = database_reviews.rawQuery(grocery_result, null);
        if (main_cursor.getCount() > 0) {
            main_cursor.moveToFirst();
            name.setText(main_cursor.getString(0));
            home.setText(main_cursor.getString(1));
            rating.setText("Rating:" + main_cursor.getInt(2));
            category.setText(main_cursor.getString(3));
            price.setText(main_cursor.getString(4));
            service.setText(main_cursor.getString(5));
            byte[] b_photo = main_cursor.getBlob(6);
            Bitmap picture = BitmapFactory.decodeByteArray(b_photo, 0, b_photo.length);
            foto.setBackgroundResource(0);
            foto.setImageBitmap(picture);
            if (main_cursor.moveToNext() == true) {
                TextView second_name = findViewById(R.id.life_name_two);
                TextView second_home = findViewById(R.id.life_address_two);
                TextView second_rating = findViewById(R.id.life_rating_two);
                TextView second_category = findViewById(R.id.life_category_two);
                TextView second_price = findViewById(R.id.life_price_two);
                TextView second_service = findViewById(R.id.life_service_two);
                second_name.setText(main_cursor.getString(0));
                second_home.setText(main_cursor.getString(1));
                second_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                second_category.setText(main_cursor.getString(3));
                second_price.setText(main_cursor.getString(4));
                second_service.setText("Service:" + main_cursor.getString(5));
                byte[] second_b_photo = main_cursor.getBlob(6);
                Bitmap second_picture = BitmapFactory.decodeByteArray(second_b_photo, 0, second_b_photo.length);
                second_foto.setBackgroundResource(0);
                second_foto.setImageBitmap(second_picture);
                if (main_cursor.moveToNext() == true) {
                    TextView third_name = findViewById(R.id.life_name_three);
                    TextView third_home = findViewById(R.id.life_address_three);
                    TextView third_rating = findViewById(R.id.life_rating_three);
                    TextView third_category = findViewById(R.id.life_category_three);
                    TextView third_price = findViewById(R.id.life_price_three);
                    TextView third_service = findViewById(R.id.life_service_three);
                    third_name.setText(main_cursor.getString(0));
                    third_home.setText(main_cursor.getString(1));
                    third_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                    third_category.setText(main_cursor.getString(3));
                    third_price.setText(main_cursor.getString(4));
                    third_service.setText(main_cursor.getString(5));
                    byte[] third_b_photo = main_cursor.getBlob(6);
                    Bitmap third_picture = BitmapFactory.decodeByteArray(third_b_photo, 0, third_b_photo.length);
                    third_foto.setBackgroundResource(0);
                    third_foto.setImageBitmap(third_picture);


                }
            }
        }

    }

    public void haircut_results(View view) {
        Log.v("LIFESTYLE", "GROCERIES");
        setContentView(R.layout.top_life);
        TextView name = findViewById(R.id.life_name_one);
        TextView home = findViewById(R.id.life_address_one);
        TextView rating = findViewById(R.id.life_rating_one);
        TextView category = findViewById(R.id.life_category_one);
        TextView price = findViewById(R.id.life_price_one);
        TextView service = findViewById(R.id.life_service_one);
        ImageView foto = findViewById(R.id.life_one_pic);
        ImageView second_foto = findViewById(R.id.life_two_pic);
        ImageView third_foto = findViewById(R.id.life_three_pic);
        String haircut = "Category:Haircut";
        String grocery_result = "select * from Lifestyle L where L.Category = " + "'" + haircut + "'" + "order by L.Rating desc;";
        main_cursor = database_reviews.rawQuery(grocery_result, null);
        if (main_cursor.getCount() > 0) {
            main_cursor.moveToFirst();
            name.setText(main_cursor.getString(0));
            home.setText(main_cursor.getString(1));
            rating.setText("Rating:" + main_cursor.getInt(2));
            category.setText(main_cursor.getString(3));
            price.setText(main_cursor.getString(4));
            service.setText(main_cursor.getString(5));
            byte[] b_photo = main_cursor.getBlob(6);
            Bitmap picture = BitmapFactory.decodeByteArray(b_photo, 0, b_photo.length);
            foto.setBackgroundResource(0);
            foto.setImageBitmap(picture);
            if (main_cursor.moveToNext() == true) {
                TextView second_name = findViewById(R.id.life_name_two);
                TextView second_home = findViewById(R.id.life_address_two);
                TextView second_rating = findViewById(R.id.life_rating_two);
                TextView second_category = findViewById(R.id.life_category_two);
                TextView second_price = findViewById(R.id.life_price_two);
                TextView second_service = findViewById(R.id.life_service_two);
                second_name.setText(main_cursor.getString(0));
                second_home.setText(main_cursor.getString(1));
                second_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                second_category.setText(main_cursor.getString(3));
                second_price.setText(main_cursor.getString(4));
                second_service.setText("Service:" + main_cursor.getString(5));
                byte[] second_b_photo = main_cursor.getBlob(6);
                Bitmap second_picture = BitmapFactory.decodeByteArray(second_b_photo, 0, second_b_photo.length);
                second_foto.setBackgroundResource(0);
                second_foto.setImageBitmap(second_picture);
                if (main_cursor.moveToNext() == true) {
                    TextView third_name = findViewById(R.id.life_name_three);
                    TextView third_home = findViewById(R.id.life_address_three);
                    TextView third_rating = findViewById(R.id.life_rating_three);
                    TextView third_category = findViewById(R.id.life_category_three);
                    TextView third_price = findViewById(R.id.life_price_three);
                    TextView third_service = findViewById(R.id.life_service_three);
                    third_name.setText(main_cursor.getString(0));
                    third_home.setText(main_cursor.getString(1));
                    third_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                    third_category.setText(main_cursor.getString(3));
                    third_price.setText(main_cursor.getString(4));
                    third_service.setText(main_cursor.getString(5));
                    byte[] third_b_photo = main_cursor.getBlob(6);
                    Bitmap third_picture = BitmapFactory.decodeByteArray(third_b_photo, 0, third_b_photo.length);
                    third_foto.setBackgroundResource(0);
                    third_foto.setImageBitmap(third_picture);


                }
            }
        }

    }

    public void all_lifestyle_results(View view) {
        Log.v("LIFESTYLE", "GROCERIES");
        setContentView(R.layout.top_life);
        TextView name = findViewById(R.id.life_name_one);
        TextView home = findViewById(R.id.life_address_one);
        TextView rating = findViewById(R.id.life_rating_one);
        TextView category = findViewById(R.id.life_category_one);
        TextView price = findViewById(R.id.life_price_one);
        TextView service = findViewById(R.id.life_service_one);
        ImageView foto = findViewById(R.id.life_one_pic);
        ImageView second_foto = findViewById(R.id.life_two_pic);
        ImageView third_foto = findViewById(R.id.life_three_pic);
        String haircut = "Category:Haircut";
        String grocery_result = "select * from Lifestyle L order by L.Rating desc;";
        main_cursor = database_reviews.rawQuery(grocery_result, null);
        if (main_cursor.getCount() > 0) {
            main_cursor.moveToFirst();
            name.setText(main_cursor.getString(0));
            home.setText(main_cursor.getString(1));
            rating.setText("Rating:" + main_cursor.getInt(2));
            category.setText(main_cursor.getString(3));
            price.setText(main_cursor.getString(4));
            service.setText(main_cursor.getString(5));
            byte[] b_photo = main_cursor.getBlob(6);
            Bitmap picture = BitmapFactory.decodeByteArray(b_photo, 0, b_photo.length);
            foto.setBackgroundResource(0);
            foto.setImageBitmap(picture);
            if (main_cursor.moveToNext() == true) {
                TextView second_name = findViewById(R.id.life_name_two);
                TextView second_home = findViewById(R.id.life_address_two);
                TextView second_rating = findViewById(R.id.life_rating_two);
                TextView second_category = findViewById(R.id.life_category_two);
                TextView second_price = findViewById(R.id.life_price_two);
                TextView second_service = findViewById(R.id.life_service_two);
                second_name.setText(main_cursor.getString(0));
                second_home.setText(main_cursor.getString(1));
                second_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                second_category.setText(main_cursor.getString(3));
                second_price.setText(main_cursor.getString(4));
                second_service.setText("Service:" + main_cursor.getString(5));
                byte[] second_b_photo = main_cursor.getBlob(6);
                Bitmap second_picture = BitmapFactory.decodeByteArray(second_b_photo, 0, second_b_photo.length);
                second_foto.setBackgroundResource(0);
                second_foto.setImageBitmap(second_picture);
                if (main_cursor.moveToNext() == true) {
                    TextView third_name = findViewById(R.id.life_name_three);
                    TextView third_home = findViewById(R.id.life_address_three);
                    TextView third_rating = findViewById(R.id.life_rating_three);
                    TextView third_category = findViewById(R.id.life_category_three);
                    TextView third_price = findViewById(R.id.life_price_three);
                    TextView third_service = findViewById(R.id.life_service_three);
                    third_name.setText(main_cursor.getString(0));
                    third_home.setText(main_cursor.getString(1));
                    third_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                    third_category.setText(main_cursor.getString(3));
                    third_price.setText(main_cursor.getString(4));
                    third_service.setText(main_cursor.getString(5));
                    byte[] third_b_photo = main_cursor.getBlob(6);
                    Bitmap third_picture = BitmapFactory.decodeByteArray(third_b_photo, 0, third_b_photo.length);
                    third_foto.setBackgroundResource(0);
                    third_foto.setImageBitmap(third_picture);


                }
            }
        }

    }



    public void l_back(View view) {
        setContentView(R.layout.thrillz);
    }

    public void life_results(View view) {
        setContentView(R.layout.top_life);
    }

    public void e_back(View view) {
        setContentView(R.layout.thrillz);
    }

    public void fun_results(View view) {
        setContentView(R.layout.top_fun);
    }

    public void food_r_back(View view) {
        setContentView(R.layout.mealz);
    }

    public void adv_food(View view) {
        setContentView(R.layout.adv_food_search);
    }

    public void adv_food_back(View view) {
        setContentView(R.layout.top_food);
    }

    public void life_r_back(View view) {
        setContentView(R.layout.l_style);
    }

    public void adv_life(View view) {
        setContentView(R.layout.adv_life_search);
    }

    public void adv_life_back(View view) {
        setContentView(R.layout.top_life);
    }

    public void fun_r_back(View view) {
        setContentView(R.layout.fun);
    }

    public void adv_fun(View view) {
        setContentView(R.layout.adv_fun_search);
    }

    public void adv_fun_back(View view) {
        setContentView(R.layout.top_fun);
    }

    public void review(View view) {
        setContentView(R.layout.reviews_homepage);
    }

    public void back_home(View view) {
        setContentView(R.layout.activity_main);
    }

    public void food_review(View view) {
        setContentView(R.layout.food_review);
    }

    public void lifestyle_review(View view) {
        setContentView(R.layout.lifestyle_review);
    }

    public void entertainment_review(View view) {
        setContentView(R.layout.entertainment_review);
    }

    public void food_review_back(View view) {
        num_stars = 0;
        mealz = null;
        prices = null;
        food_type = null;
        setContentView(R.layout.reviews_homepage);
    }

    public void lifestyle_review_back(View view) {
        setContentView(R.layout.reviews_homepage);
    }

    public void entertainment_review_back(View view) {
        setContentView(R.layout.reviews_homepage);
    }

    public void food_submit(View view) {
        Context context = getApplicationContext();
        EditText restaurant = findViewById(R.id.restaurant);
        EditText address = findViewById(R.id.address);
        if (restaurant.length() == 0) {
            Toast no_restaurant = Toast.makeText(context, "No Restaurant Name Specified", Toast.LENGTH_LONG);
            no_restaurant.show();
        } else if (address.length() == 0) {
            Toast no_address = Toast.makeText(context, "No Address Specified", Toast.LENGTH_LONG);
            no_address.show();
        } else {
            ContentValues values = new ContentValues();
            ImageView resto_pic = findViewById(R.id.r_one_pic);
            TextView name = findViewById(R.id.restaurant_one);
            TextView home = findViewById(R.id.address_one);
            TextView rating = findViewById(R.id.rating_one);
            TextView meal = findViewById(R.id.meal_one);
            TextView price = findViewById(R.id.price_one);
            TextView cuisine = findViewById(R.id.cuisine_one);
//            name.setText(restaurant.getText());
            values.put("Name", restaurant.getText().toString());
            values.put("Address", address.getText().toString());
            values.put("Rating", num_stars);
            values.put("Meal", mealz);
            values.put("Price", prices);
            values.put("Cuisine", food_type);
            ByteArrayOutputStream compressed_photo = new ByteArrayOutputStream();
            current.compress(Bitmap.CompressFormat.PNG, 0, compressed_photo);
            byte[] photo = compressed_photo.toByteArray();
            values.put("Photo", photo);
            database_reviews.insert("Food", null, values);

            num_stars = 0;
            mealz = null;
            prices = null;
            food_type = null;
            Toast saved = Toast.makeText(context, "Review Has Been Saved", Toast.LENGTH_LONG);
            saved.show();
            setContentView(R.layout.activity_main);


        }
    }

    public void lifestyle_submit(View view) {
        Context context = getApplicationContext();
        EditText name = findViewById(R.id.lifestyle_name);
        EditText lifestyle_address = findViewById(R.id.lifestyle_address);
        if (name.length() == 0) {
            Toast no_restaurant = Toast.makeText(context, "No Name Specified", Toast.LENGTH_LONG);
            no_restaurant.show();
        } else if (lifestyle_address.length() == 0) {
            Toast no_address = Toast.makeText(context, "No Address Specified", Toast.LENGTH_LONG);
            no_address.show();
        } else {
            ContentValues values = new ContentValues();
//            name.setText(restaurant.getText());
            values.put("Name", name.getText().toString());
            values.put("Address", lifestyle_address.getText().toString());
            values.put("Rating", num_stars);
            values.put("Category", category);
            values.put("Price", lifestyle_price);
            values.put("Service", service_stars);
            ByteArrayOutputStream compressed_photo = new ByteArrayOutputStream();
            current.compress(Bitmap.CompressFormat.PNG, 0, compressed_photo);
            byte[] photo = compressed_photo.toByteArray();
            values.put("Photo", photo);
            database_reviews.insert("Lifestyle", null, values);

            num_stars = 0;
            service_stars = 0;
            category = null;
            lifestyle_price = null;
            Toast saved = Toast.makeText(context, "Review Has Been Saved", Toast.LENGTH_LONG);
            saved.show();
            setContentView(R.layout.activity_main);


        }
    }

    public void entertainment_submit(View view) {
        Context context = getApplicationContext();
        EditText restaurant = findViewById(R.id.restaurant);
        EditText address = findViewById(R.id.address);
        if (restaurant.length() == 0) {
            Toast no_restaurant = Toast.makeText(context, "No Restaurant Name Specified", Toast.LENGTH_LONG);
            no_restaurant.show();
        } else if (address.length() == 0) {
            Toast no_address = Toast.makeText(context, "No Address Specified", Toast.LENGTH_LONG);
            no_address.show();
        } else {
            ContentValues values = new ContentValues();
            ImageView resto_pic = findViewById(R.id.r_one_pic);
            TextView name = findViewById(R.id.restaurant_one);
            TextView home = findViewById(R.id.address_one);
            TextView rating = findViewById(R.id.rating_one);
            TextView meal = findViewById(R.id.meal_one);
            TextView price = findViewById(R.id.price_one);
            TextView cuisine = findViewById(R.id.cuisine_one);
//            name.setText(restaurant.getText());
            values.put("Name", restaurant.getText().toString());
            values.put("Address", address.getText().toString());
            values.put("Rating", num_stars);
            values.put("Meal", mealz);
            values.put("Price", prices);
            values.put("Cuisine", food_type);
            ByteArrayOutputStream compressed_photo = new ByteArrayOutputStream();
            current.compress(Bitmap.CompressFormat.PNG, 0, compressed_photo);
            byte[] photo = compressed_photo.toByteArray();
            values.put("Photo", photo);
            database_reviews.insert("Food", null, values);

            num_stars = 0;
            mealz = null;
            prices = null;
            food_type = null;
            Toast saved = Toast.makeText(context, "Review Has Been Saved", Toast.LENGTH_LONG);
            saved.show();
            setContentView(R.layout.activity_main);


        }
    }

    public void next_row(View view) {
        Log.v("Button", "Next");
        TextView name = findViewById(R.id.restaurant_one);
        name.setText("");
        TextView home = findViewById(R.id.address_one);
        home.setText("");
        TextView rating = findViewById(R.id.rating_one);
        rating.setText("");
        TextView meal = findViewById(R.id.meal_one);
        meal.setText("");
        TextView price = findViewById(R.id.price_one);
        price.setText("");
        TextView cuisine = findViewById(R.id.cuisine_one);
        cuisine.setText("");
        TextView number_one = findViewById(R.id.one);
        TextView number_two = findViewById(R.id.two);
        TextView number_three = findViewById(R.id.three);
        TextView second_name = findViewById(R.id.restaurant_two);
        second_name.setText("");
        TextView second_home = findViewById(R.id.address_two);
        second_home.setText("");
        TextView second_rating = findViewById(R.id.rating_two);
        second_rating.setText("");
        TextView second_meal = findViewById(R.id.meal_two);
        second_meal.setText("");
        TextView second_price = findViewById(R.id.price_two);
        second_price.setText("");
        TextView second_cuisine = findViewById(R.id.cuisine_two);
        second_cuisine.setText("");
        TextView third_name = findViewById(R.id.restaurant_three);
        third_name.setText("");
        TextView third_home = findViewById(R.id.address_three);
        third_home.setText("");
        TextView third_rating = findViewById(R.id.rating_three);
        third_rating.setText("");
        TextView third_meal = findViewById(R.id.meal_three);
        third_meal.setText("");
        TextView third_price = findViewById(R.id.price_three);
        third_price.setText("");
        TextView third_cuisine = findViewById(R.id.cuisine_three);
        third_cuisine.setText("");
        ImageView foto = findViewById(R.id.r_one_pic);
        foto.setImageBitmap(null);
        Log.v("Button", "Image is Null");
        ImageView second_foto = findViewById(R.id.r_two_pic);
        second_foto.setImageBitmap(null);
//        second_foto.setBackgroundResource(0);
        ImageView third_foto = findViewById(R.id.r_three_pic);
        third_foto.setImageBitmap(null);
//        third_foto.setBackgroundResource(0);
        int num_one = Integer.parseInt(number_one.getText().toString());
        int num_two = Integer.parseInt(number_two.getText().toString());
        int num_three = Integer.parseInt(number_three.getText().toString());
        num_one = num_one + 3;
        num_two = num_two + 3;
        num_three = num_three + 3;
        number_one.setText(num_one + "");
        number_two.setText(num_two + "");
        number_three.setText(num_three + "");
        Log.v("POSITION:", "Before Next");
        Log.v("POSITION:", main_cursor.getPosition() + "");
        if (main_cursor.moveToPosition(num_one - 1) == true) {
            Log.v("POSITION:", "First Next");
            Log.v("POSITION:", main_cursor.getPosition() + "");
//            Log.v("Button", "New Image:" + main_cursor.getPosition());
            name.setText(main_cursor.getString(0));
            home.setText(main_cursor.getString(1));
            rating.setText("Rating:" + main_cursor.getInt(2));
            meal.setText(main_cursor.getString(3));
            price.setText(main_cursor.getString(4));
            cuisine.setText(main_cursor.getString(5));
            byte[] b_photo = main_cursor.getBlob(6);
            Bitmap picture = BitmapFactory.decodeByteArray(b_photo, 0, b_photo.length);
            foto.setBackgroundResource(0);
            foto.setImageBitmap(picture);
            if (main_cursor.moveToPosition(num_two - 1) == true) {
                Log.v("POSITION:", "Second Next");
                Log.v("POSITION:", main_cursor.getPosition() + "");
                second_name.setText(main_cursor.getString(0));
                second_home.setText(main_cursor.getString(1));
                second_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                second_meal.setText(main_cursor.getString(3));
                second_price.setText(main_cursor.getString(4));
                second_cuisine.setText(main_cursor.getString(5));
                byte[] second_b_photo = main_cursor.getBlob(6);
                Bitmap second_picture = BitmapFactory.decodeByteArray(second_b_photo, 0, second_b_photo.length);
                second_foto.setBackgroundResource(0);
                second_foto.setImageBitmap(second_picture);
                if (main_cursor.moveToPosition(num_three - 1) == true) {
                    Log.v("POSITION:", "Third Next");
                    Log.v("POSITION:", main_cursor.getPosition() + "");
                    third_name.setText(main_cursor.getString(0));
                    third_home.setText(main_cursor.getString(1));
                    third_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                    third_meal.setText(main_cursor.getString(3));
                    third_price.setText(main_cursor.getString(4));
                    third_cuisine.setText(main_cursor.getString(5));
                    byte[] third_b_photo = main_cursor.getBlob(6);
                    Bitmap third_picture = BitmapFactory.decodeByteArray(third_b_photo, 0, third_b_photo.length);
                    third_foto.setBackgroundResource(0);
                    third_foto.setImageBitmap(third_picture);


                }
            }
        }





    }

    public void previous_row(View view) {
        Log.v("Button", "Previous");
        TextView name = findViewById(R.id.restaurant_one);
        name.setText("");
        TextView home = findViewById(R.id.address_one);
        home.setText("");
        TextView rating = findViewById(R.id.rating_one);
        rating.setText("");
        TextView meal = findViewById(R.id.meal_one);
        meal.setText("");
        TextView price = findViewById(R.id.price_one);
        price.setText("");
        TextView cuisine = findViewById(R.id.cuisine_one);
        cuisine.setText("");
        TextView number_one = findViewById(R.id.one);
        TextView number_two = findViewById(R.id.two);
        TextView number_three = findViewById(R.id.three);
        TextView second_name = findViewById(R.id.restaurant_two);
        second_name.setText("");
        TextView second_home = findViewById(R.id.address_two);
        second_home.setText("");
        TextView second_rating = findViewById(R.id.rating_two);
        second_rating.setText("");
        TextView second_meal = findViewById(R.id.meal_two);
        second_meal.setText("");
        TextView second_price = findViewById(R.id.price_two);
        second_price.setText("");
        TextView second_cuisine = findViewById(R.id.cuisine_two);
        second_cuisine.setText("");
        TextView third_name = findViewById(R.id.restaurant_three);
        third_name.setText("");
        TextView third_home = findViewById(R.id.address_three);
        third_home.setText("");
        TextView third_rating = findViewById(R.id.rating_three);
        third_rating.setText("");
        TextView third_meal = findViewById(R.id.meal_three);
        third_meal.setText("");
        TextView third_price = findViewById(R.id.price_three);
        third_price.setText("");
        TextView third_cuisine = findViewById(R.id.cuisine_three);
        third_cuisine.setText("");
        ImageView foto = findViewById(R.id.r_one_pic);
        foto.setImageBitmap(null);
        ImageView second_foto = findViewById(R.id.r_two_pic);
        second_foto.setImageBitmap(null);
//        second_foto.setBackgroundResource(0);
        ImageView third_foto = findViewById(R.id.r_three_pic);
        third_foto.setImageBitmap(null);
//        third_foto.setBackgroundResource(0);
        int test = Integer.parseInt(number_one.getText().toString());
        if (test == 1) {
            setContentView(R.layout.mealz);
        } else {
            int num_one = Integer.parseInt(number_one.getText().toString());
            int num_two = Integer.parseInt(number_two.getText().toString());
            int num_three = Integer.parseInt(number_three.getText().toString());
            num_one = num_one - 3;
            num_two = num_two - 3;
            num_three = num_three - 3;
            number_one.setText(num_one + "");
            number_two.setText(num_two + "");
            number_three.setText(num_three + "");
            int reset_position = main_cursor.getPosition();
            Log.v("POSITION:", "Before Previous");
            Log.v("POSITION:", main_cursor.getPosition() + "");
            if (main_cursor.moveToPosition(num_three - 1) == true) {
                Log.v("POSITION:", "First Previous");
                Log.v("POSITION:", main_cursor.getPosition() + "");
//                Log.v("Button", "Move to Previous:" + main_cursor.getPosition());
                third_name.setText(main_cursor.getString(0));
                third_home.setText(main_cursor.getString(1));
                third_rating.setText("Rating:" + main_cursor.getInt(2));
                third_meal.setText(main_cursor.getString(3));
                third_price.setText(main_cursor.getString(4));
                third_cuisine.setText(main_cursor.getString(5));
                byte[] b_photo = main_cursor.getBlob(6);
                Bitmap picture = BitmapFactory.decodeByteArray(b_photo, 0, b_photo.length);
                third_foto.setBackgroundResource(0);
                third_foto.setImageBitmap(picture);
            }
            if (main_cursor.moveToPosition(num_two - 1) == true) {
                Log.v("POSITION:", "Second Previous");
                Log.v("POSITION:", main_cursor.getPosition() + "");
                second_name.setText(main_cursor.getString(0));
                second_home.setText(main_cursor.getString(1));
                second_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                second_meal.setText(main_cursor.getString(3));
                second_price.setText(main_cursor.getString(4));
                second_cuisine.setText(main_cursor.getString(5));
                byte[] second_b_photo = main_cursor.getBlob(6);
                Bitmap second_picture = BitmapFactory.decodeByteArray(second_b_photo, 0, second_b_photo.length);
                second_foto.setBackgroundResource(0);
                second_foto.setImageBitmap(second_picture);
            }
            if (main_cursor.moveToPosition(num_one - 1) == true) {
                        Log.v("POSITION:", "Third Previous");
                        Log.v("POSITION:", main_cursor.getPosition() + "");
                        name.setText(main_cursor.getString(0));
                        home.setText(main_cursor.getString(1));
                        rating.setText("Rating:" + main_cursor.getInt(2) + "");
                        meal.setText(main_cursor.getString(3));
                        price.setText(main_cursor.getString(4));
                        cuisine.setText(main_cursor.getString(5));
                        byte[] third_b_photo = main_cursor.getBlob(6);
                        Bitmap third_picture = BitmapFactory.decodeByteArray(third_b_photo, 0, third_b_photo.length);
                        foto.setBackgroundResource(0);
                        foto.setImageBitmap(third_picture);


                    }
                }





    }

    public void life_next_row(View view) {
        Log.v("Button", "Next");
        TextView name = findViewById(R.id.life_name_one);
        name.setText("");
        TextView home = findViewById(R.id.life_address_one);
        home.setText("");
        TextView rating = findViewById(R.id.life_rating_one);
        rating.setText("");
        TextView category = findViewById(R.id.life_category_one);
        category.setText("");
        TextView price = findViewById(R.id.life_price_one);
        price.setText("");
        TextView service = findViewById(R.id.life_service_one);
        service.setText("");
        TextView number_one = findViewById(R.id.life_one);
        TextView number_two = findViewById(R.id.life_two);
        TextView number_three = findViewById(R.id.life_three);
        TextView second_name = findViewById(R.id.life_name_two);
        second_name.setText("");
        TextView second_home = findViewById(R.id.life_address_two);
        second_home.setText("");
        TextView second_rating = findViewById(R.id.life_rating_two);
        second_rating.setText("");
        TextView second_category = findViewById(R.id.life_category_two);
        second_category.setText("");
        TextView second_price = findViewById(R.id.life_price_two);
        second_price.setText("");
        TextView second_service = findViewById(R.id.life_service_two);
        second_service.setText("");
        TextView third_name = findViewById(R.id.life_name_three);
        third_name.setText("");
        TextView third_home = findViewById(R.id.life_address_three);
        third_home.setText("");
        TextView third_rating = findViewById(R.id.life_rating_three);
        third_rating.setText("");
        TextView third_category = findViewById(R.id.life_category_three);
        third_category.setText("");
        TextView third_price = findViewById(R.id.life_price_three);
        third_price.setText("");
        TextView third_service = findViewById(R.id.life_service_three);
        third_service.setText("");
        ImageView foto = findViewById(R.id.life_one_pic);
        foto.setImageBitmap(null);
        Log.v("Button", "Image is Null");
        ImageView second_foto = findViewById(R.id.life_two_pic);
        second_foto.setImageBitmap(null);
//        second_foto.setBackgroundResource(0);
        ImageView third_foto = findViewById(R.id.life_three_pic);
        third_foto.setImageBitmap(null);
//        third_foto.setBackgroundResource(0);
        int num_one = Integer.parseInt(number_one.getText().toString());
        int num_two = Integer.parseInt(number_two.getText().toString());
        int num_three = Integer.parseInt(number_three.getText().toString());
        num_one = num_one + 3;
        num_two = num_two + 3;
        num_three = num_three + 3;
        number_one.setText(num_one + "");
        number_two.setText(num_two + "");
        number_three.setText(num_three + "");
        Log.v("POSITION:", "Before Next");
        Log.v("POSITION:", main_cursor.getPosition() + "");
        if (main_cursor.moveToPosition(num_one - 1) == true) {
            Log.v("POSITION:", "First Next");
            Log.v("POSITION:", main_cursor.getPosition() + "");
//            Log.v("Button", "New Image:" + main_cursor.getPosition());
            name.setText(main_cursor.getString(0));
            home.setText(main_cursor.getString(1));
            rating.setText("Rating:" + main_cursor.getInt(2));
            category.setText(main_cursor.getString(3));
            price.setText(main_cursor.getString(4));
            service.setText("Service:" + main_cursor.getString(5));
            byte[] b_photo = main_cursor.getBlob(6);
            Bitmap picture = BitmapFactory.decodeByteArray(b_photo, 0, b_photo.length);
            foto.setBackgroundResource(0);
            foto.setImageBitmap(picture);
            if (main_cursor.moveToPosition(num_two - 1) == true) {
                Log.v("POSITION:", "Second Next");
                Log.v("POSITION:", main_cursor.getPosition() + "");
                second_name.setText(main_cursor.getString(0));
                second_home.setText(main_cursor.getString(1));
                second_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                second_category.setText(main_cursor.getString(3));
                second_price.setText(main_cursor.getString(4));
                second_service.setText("Service:" + main_cursor.getString(5));
                byte[] second_b_photo = main_cursor.getBlob(6);
                Bitmap second_picture = BitmapFactory.decodeByteArray(second_b_photo, 0, second_b_photo.length);
                second_foto.setBackgroundResource(0);
                second_foto.setImageBitmap(second_picture);
                if (main_cursor.moveToPosition(num_three - 1) == true) {
                    Log.v("POSITION:", "Third Next");
                    Log.v("POSITION:", main_cursor.getPosition() + "");
                    third_name.setText(main_cursor.getString(0));
                    third_home.setText(main_cursor.getString(1));
                    third_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                    third_category.setText(main_cursor.getString(3));
                    third_price.setText(main_cursor.getString(4));
                    third_service.setText("Service:" + main_cursor.getString(5));
                    byte[] third_b_photo = main_cursor.getBlob(6);
                    Bitmap third_picture = BitmapFactory.decodeByteArray(third_b_photo, 0, third_b_photo.length);
                    third_foto.setBackgroundResource(0);
                    third_foto.setImageBitmap(third_picture);


                }
            }
        }





    }

    public void life_previous_row(View view) {
        Log.v("Button", "Previous");
        TextView name = findViewById(R.id.life_name_one);
        name.setText("");
        TextView home = findViewById(R.id.life_address_one);
        home.setText("");
        TextView rating = findViewById(R.id.life_rating_one);
        rating.setText("");
        TextView category = findViewById(R.id.life_category_one);
        category.setText("");
        TextView price = findViewById(R.id.life_price_one);
        price.setText("");
        TextView service = findViewById(R.id.life_service_one);
        service.setText("");
        TextView number_one = findViewById(R.id.life_one);
        TextView number_two = findViewById(R.id.life_two);
        TextView number_three = findViewById(R.id.life_three);
        TextView second_name = findViewById(R.id.life_name_two);
        second_name.setText("");
        TextView second_home = findViewById(R.id.life_address_two);
        second_home.setText("");
        TextView second_rating = findViewById(R.id.life_rating_two);
        second_rating.setText("");
        TextView second_category = findViewById(R.id.life_category_two);
        second_category.setText("");
        TextView second_price = findViewById(R.id.life_price_two);
        second_price.setText("");
        TextView second_service = findViewById(R.id.life_service_two);
        second_service.setText("");
        TextView third_name = findViewById(R.id.life_name_three);
        third_name.setText("");
        TextView third_home = findViewById(R.id.life_address_three);
        third_home.setText("");
        TextView third_rating = findViewById(R.id.life_rating_three);
        third_rating.setText("");
        TextView third_category = findViewById(R.id.life_category_three);
        third_category.setText("");
        TextView third_price = findViewById(R.id.life_price_three);
        third_price.setText("");
        TextView third_service = findViewById(R.id.life_service_three);
        third_service.setText("");
        ImageView foto = findViewById(R.id.life_one_pic);
        foto.setImageBitmap(null);
        ImageView second_foto = findViewById(R.id.life_two_pic);
        second_foto.setImageBitmap(null);
//        second_foto.setBackgroundResource(0);
        ImageView third_foto = findViewById(R.id.life_three_pic);
        third_foto.setImageBitmap(null);
//        third_foto.setBackgroundResource(0);
        int test = Integer.parseInt(number_one.getText().toString());
        if (test == 1) {
            setContentView(R.layout.l_style);
        } else {
            int num_one = Integer.parseInt(number_one.getText().toString());
            int num_two = Integer.parseInt(number_two.getText().toString());
            int num_three = Integer.parseInt(number_three.getText().toString());
            num_one = num_one - 3;
            num_two = num_two - 3;
            num_three = num_three - 3;
            number_one.setText(num_one + "");
            number_two.setText(num_two + "");
            number_three.setText(num_three + "");
            int reset_position = main_cursor.getPosition();
            Log.v("POSITION:", "Before Previous");
            Log.v("POSITION:", main_cursor.getPosition() + "");
            if (main_cursor.moveToPosition(num_three - 1) == true) {
                Log.v("POSITION:", "First Previous");
                Log.v("POSITION:", main_cursor.getPosition() + "");
//                Log.v("Button", "Move to Previous:" + main_cursor.getPosition());
                third_name.setText(main_cursor.getString(0));
                third_home.setText(main_cursor.getString(1));
                third_rating.setText("Rating:" + main_cursor.getInt(2));
                third_category.setText(main_cursor.getString(3));
                third_price.setText(main_cursor.getString(4));
                third_service.setText("Service:" + main_cursor.getString(5));
                byte[] b_photo = main_cursor.getBlob(6);
                Bitmap picture = BitmapFactory.decodeByteArray(b_photo, 0, b_photo.length);
                third_foto.setBackgroundResource(0);
                third_foto.setImageBitmap(picture);
            }
            if (main_cursor.moveToPosition(num_two - 1) == true) {
                Log.v("POSITION:", "Second Previous");
                Log.v("POSITION:", main_cursor.getPosition() + "");
                second_name.setText(main_cursor.getString(0));
                second_home.setText(main_cursor.getString(1));
                second_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                second_category.setText(main_cursor.getString(3));
                second_price.setText(main_cursor.getString(4));
                second_service.setText("Service:" + main_cursor.getString(5));
                byte[] second_b_photo = main_cursor.getBlob(6);
                Bitmap second_picture = BitmapFactory.decodeByteArray(second_b_photo, 0, second_b_photo.length);
                second_foto.setBackgroundResource(0);
                second_foto.setImageBitmap(second_picture);
            }
            if (main_cursor.moveToPosition(num_one - 1) == true) {
                Log.v("POSITION:", "Third Previous");
                Log.v("POSITION:", main_cursor.getPosition() + "");
                name.setText(main_cursor.getString(0));
                home.setText(main_cursor.getString(1));
                rating.setText("Rating:" + main_cursor.getInt(2) + "");
                category.setText(main_cursor.getString(3));
                price.setText(main_cursor.getString(4));
                service.setText("Service:" + main_cursor.getString(5));
                byte[] third_b_photo = main_cursor.getBlob(6);
                Bitmap third_picture = BitmapFactory.decodeByteArray(third_b_photo, 0, third_b_photo.length);
                foto.setBackgroundResource(0);
                foto.setImageBitmap(third_picture);


            }
        }





    }

    public void fun_next_row(View view) {
        Log.v("Button", "Next");
        TextView name = findViewById(R.id.life_name_one);
        name.setText("");
        TextView home = findViewById(R.id.life_address_one);
        home.setText("");
        TextView rating = findViewById(R.id.life_rating_one);
        rating.setText("");
        TextView category = findViewById(R.id.life_category_one);
        category.setText("");
        TextView price = findViewById(R.id.life_price_one);
        price.setText("");
        TextView service = findViewById(R.id.life_service_one);
        service.setText("");
        TextView number_one = findViewById(R.id.life_one);
        TextView number_two = findViewById(R.id.life_two);
        TextView number_three = findViewById(R.id.life_three);
        TextView second_name = findViewById(R.id.life_name_two);
        second_name.setText("");
        TextView second_home = findViewById(R.id.life_address_two);
        second_home.setText("");
        TextView second_rating = findViewById(R.id.life_rating_two);
        second_rating.setText("");
        TextView second_category = findViewById(R.id.life_category_two);
        second_category.setText("");
        TextView second_price = findViewById(R.id.life_price_two);
        second_price.setText("");
        TextView second_service = findViewById(R.id.life_service_two);
        second_service.setText("");
        TextView third_name = findViewById(R.id.life_name_three);
        third_name.setText("");
        TextView third_home = findViewById(R.id.life_address_three);
        third_home.setText("");
        TextView third_rating = findViewById(R.id.life_rating_three);
        third_rating.setText("");
        TextView third_category = findViewById(R.id.life_category_three);
        third_category.setText("");
        TextView third_price = findViewById(R.id.life_price_three);
        third_price.setText("");
        TextView third_service = findViewById(R.id.life_service_three);
        third_service.setText("");
        ImageView foto = findViewById(R.id.life_one_pic);
        foto.setImageBitmap(null);
        Log.v("Button", "Image is Null");
        ImageView second_foto = findViewById(R.id.life_two_pic);
        second_foto.setImageBitmap(null);
//        second_foto.setBackgroundResource(0);
        ImageView third_foto = findViewById(R.id.life_three_pic);
        third_foto.setImageBitmap(null);
//        third_foto.setBackgroundResource(0);
        int num_one = Integer.parseInt(number_one.getText().toString());
        int num_two = Integer.parseInt(number_two.getText().toString());
        int num_three = Integer.parseInt(number_three.getText().toString());
        num_one = num_one + 3;
        num_two = num_two + 3;
        num_three = num_three + 3;
        number_one.setText(num_one + "");
        number_two.setText(num_two + "");
        number_three.setText(num_three + "");
        Log.v("POSITION:", "Before Next");
        Log.v("POSITION:", main_cursor.getPosition() + "");
        if (main_cursor.moveToPosition(num_one - 1) == true) {
            Log.v("POSITION:", "First Next");
            Log.v("POSITION:", main_cursor.getPosition() + "");
//            Log.v("Button", "New Image:" + main_cursor.getPosition());
            name.setText(main_cursor.getString(0));
            home.setText(main_cursor.getString(1));
            rating.setText("Rating:" + main_cursor.getInt(2));
            category.setText(main_cursor.getString(3));
            price.setText(main_cursor.getString(4));
            service.setText("Service:" + main_cursor.getString(5));
            byte[] b_photo = main_cursor.getBlob(6);
            Bitmap picture = BitmapFactory.decodeByteArray(b_photo, 0, b_photo.length);
            foto.setBackgroundResource(0);
            foto.setImageBitmap(picture);
            if (main_cursor.moveToPosition(num_two - 1) == true) {
                Log.v("POSITION:", "Second Next");
                Log.v("POSITION:", main_cursor.getPosition() + "");
                second_name.setText(main_cursor.getString(0));
                second_home.setText(main_cursor.getString(1));
                second_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                second_category.setText(main_cursor.getString(3));
                second_price.setText(main_cursor.getString(4));
                second_service.setText("Service:" + main_cursor.getString(5));
                byte[] second_b_photo = main_cursor.getBlob(6);
                Bitmap second_picture = BitmapFactory.decodeByteArray(second_b_photo, 0, second_b_photo.length);
                second_foto.setBackgroundResource(0);
                second_foto.setImageBitmap(second_picture);
                if (main_cursor.moveToPosition(num_three - 1) == true) {
                    Log.v("POSITION:", "Third Next");
                    Log.v("POSITION:", main_cursor.getPosition() + "");
                    third_name.setText(main_cursor.getString(0));
                    third_home.setText(main_cursor.getString(1));
                    third_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                    third_category.setText(main_cursor.getString(3));
                    third_price.setText(main_cursor.getString(4));
                    third_service.setText("Service:" + main_cursor.getString(5));
                    byte[] third_b_photo = main_cursor.getBlob(6);
                    Bitmap third_picture = BitmapFactory.decodeByteArray(third_b_photo, 0, third_b_photo.length);
                    third_foto.setBackgroundResource(0);
                    third_foto.setImageBitmap(third_picture);


                }
            }
        }





    }

    public void fun_previous_row(View view) {
        Log.v("Button", "Previous");
        TextView name = findViewById(R.id.life_name_one);
        name.setText("");
        TextView home = findViewById(R.id.life_address_one);
        home.setText("");
        TextView rating = findViewById(R.id.life_rating_one);
        rating.setText("");
        TextView category = findViewById(R.id.life_category_one);
        category.setText("");
        TextView price = findViewById(R.id.life_price_one);
        price.setText("");
        TextView service = findViewById(R.id.life_service_one);
        service.setText("");
        TextView number_one = findViewById(R.id.life_one);
        TextView number_two = findViewById(R.id.life_two);
        TextView number_three = findViewById(R.id.life_three);
        TextView second_name = findViewById(R.id.life_name_two);
        second_name.setText("");
        TextView second_home = findViewById(R.id.life_address_two);
        second_home.setText("");
        TextView second_rating = findViewById(R.id.life_rating_two);
        second_rating.setText("");
        TextView second_category = findViewById(R.id.life_category_two);
        second_category.setText("");
        TextView second_price = findViewById(R.id.life_price_two);
        second_price.setText("");
        TextView second_service = findViewById(R.id.life_service_two);
        second_service.setText("");
        TextView third_name = findViewById(R.id.life_name_three);
        third_name.setText("");
        TextView third_home = findViewById(R.id.life_address_three);
        third_home.setText("");
        TextView third_rating = findViewById(R.id.life_rating_three);
        third_rating.setText("");
        TextView third_category = findViewById(R.id.life_category_three);
        third_category.setText("");
        TextView third_price = findViewById(R.id.life_price_three);
        third_price.setText("");
        TextView third_service = findViewById(R.id.life_service_three);
        third_service.setText("");
        ImageView foto = findViewById(R.id.life_one_pic);
        foto.setImageBitmap(null);
        ImageView second_foto = findViewById(R.id.life_two_pic);
        second_foto.setImageBitmap(null);
//        second_foto.setBackgroundResource(0);
        ImageView third_foto = findViewById(R.id.life_three_pic);
        third_foto.setImageBitmap(null);
//        third_foto.setBackgroundResource(0);
        int test = Integer.parseInt(number_one.getText().toString());
        if (test == 1) {
            setContentView(R.layout.l_style);
        } else {
            int num_one = Integer.parseInt(number_one.getText().toString());
            int num_two = Integer.parseInt(number_two.getText().toString());
            int num_three = Integer.parseInt(number_three.getText().toString());
            num_one = num_one - 3;
            num_two = num_two - 3;
            num_three = num_three - 3;
            number_one.setText(num_one + "");
            number_two.setText(num_two + "");
            number_three.setText(num_three + "");
            int reset_position = main_cursor.getPosition();
            Log.v("POSITION:", "Before Previous");
            Log.v("POSITION:", main_cursor.getPosition() + "");
            if (main_cursor.moveToPosition(num_three - 1) == true) {
                Log.v("POSITION:", "First Previous");
                Log.v("POSITION:", main_cursor.getPosition() + "");
//                Log.v("Button", "Move to Previous:" + main_cursor.getPosition());
                third_name.setText(main_cursor.getString(0));
                third_home.setText(main_cursor.getString(1));
                third_rating.setText("Rating:" + main_cursor.getInt(2));
                third_category.setText(main_cursor.getString(3));
                third_price.setText(main_cursor.getString(4));
                third_service.setText("Service:" + main_cursor.getString(5));
                byte[] b_photo = main_cursor.getBlob(6);
                Bitmap picture = BitmapFactory.decodeByteArray(b_photo, 0, b_photo.length);
                third_foto.setBackgroundResource(0);
                third_foto.setImageBitmap(picture);
            }
            if (main_cursor.moveToPosition(num_two - 1) == true) {
                Log.v("POSITION:", "Second Previous");
                Log.v("POSITION:", main_cursor.getPosition() + "");
                second_name.setText(main_cursor.getString(0));
                second_home.setText(main_cursor.getString(1));
                second_rating.setText("Rating:" + main_cursor.getInt(2) + "");
                second_category.setText(main_cursor.getString(3));
                second_price.setText(main_cursor.getString(4));
                second_service.setText("Service:" + main_cursor.getString(5));
                byte[] second_b_photo = main_cursor.getBlob(6);
                Bitmap second_picture = BitmapFactory.decodeByteArray(second_b_photo, 0, second_b_photo.length);
                second_foto.setBackgroundResource(0);
                second_foto.setImageBitmap(second_picture);
            }
            if (main_cursor.moveToPosition(num_one - 1) == true) {
                Log.v("POSITION:", "Third Previous");
                Log.v("POSITION:", main_cursor.getPosition() + "");
                name.setText(main_cursor.getString(0));
                home.setText(main_cursor.getString(1));
                rating.setText("Rating:" + main_cursor.getInt(2) + "");
                category.setText(main_cursor.getString(3));
                price.setText(main_cursor.getString(4));
                service.setText("Service:" + main_cursor.getString(5));
                byte[] third_b_photo = main_cursor.getBlob(6);
                Bitmap third_picture = BitmapFactory.decodeByteArray(third_b_photo, 0, third_b_photo.length);
                foto.setBackgroundResource(0);
                foto.setImageBitmap(third_picture);


            }
        }





    }

    public void food_yellow_star(View view) {
        if (view.getTag().toString() != "yellow") {
            view.setBackgroundResource(R.drawable.yellow_star);
            view.setTag("yellow");
            num_stars = num_stars + 1;
            Log.v("FOCUS", num_stars + "");

        } else if (view.getTag().toString() == "yellow") {
            view.setBackgroundResource(R.drawable.star);
            view.setTag("white");
            num_stars = num_stars - 1;
            Log.v("FOCUS", num_stars + "");

        }


    }

    public void lifestyle_yellow_star(View view) {
        if (view.getTag().toString() != "yellow") {
            view.setBackgroundResource(R.drawable.yellow_star);
            view.setTag("yellow");
            num_stars = num_stars + 1;
            Log.v("FOCUS", num_stars + "");
        } else if (view.getTag().toString() == "yellow") {
            view.setBackgroundResource(R.drawable.star);
            view.setTag("white");
            num_stars = num_stars - 1;
            Log.v("FOCUS", num_stars + "");

        }

    }

    public void lifestyle_service_star(View view) {
        if (view.getTag().toString() != "yellow") {
            view.setBackgroundResource(R.drawable.yellow_star);
            view.setTag("yellow");
            service_stars = service_stars + 1;
            Log.v("FOCUS", service_stars + "");
        } else if (view.getTag().toString() == "yellow") {
            view.setBackgroundResource(R.drawable.star);
            view.setTag("white");
            service_stars = service_stars - 1;
            Log.v("FOCUS", service_stars + "");

        }

    }

    public void fun_yellow_star(View view) {
        if (view.getTag().toString() != "yellow") {
            view.setBackgroundResource(R.drawable.yellow_star);
            view.setTag("yellow");
            num_stars = num_stars + 1;
        } else if (view.getTag().toString() == "yellow") {
            view.setBackgroundResource(R.drawable.star);
            view.setTag("white");
            num_stars = num_stars - 1;

        }

    }

    public void food_green_dot(View view) {
        Log.v("FOCUS", view.isFocusable() + "");
        // switch if statements back to tags
        if (view.isFocusable() == true) {
            view.setBackgroundResource(R.drawable.green_dot);
            view.setFocusable(false);
            if (view.getTag().toString().contains("Meal")) {
                mealz = view.getTag().toString();
            } else if (view.getTag().toString().contains("Price")) {
                prices = view.getTag().toString();
            } else if (view.getTag().toString().contains("Cuisine")) {
                food_type = view.getTag().toString();
            }
            Log.v("FOCUS", mealz + "");
        } else if (view.isFocusable() == false) {
            view.setBackgroundResource(R.drawable.circle);
            view.setFocusable(true);
            if (view.getTag().toString().contains("Meal")) {
                mealz = null;
            } else if (view.getTag().toString().contains("Price")) {
                prices = null;
            } else if (view.getTag().toString().contains("Cuisine")) {
                food_type = null;
            }


        }

    }

    public void lifestyle_green_dot(View view) {
        if (view.isFocusable() == true) {
            view.setBackgroundResource(R.drawable.green_dot);
            view.setFocusable(false);
            if (view.getTag().toString().contains("Category")) {
                category = view.getTag().toString();
            } else if (view.getTag().toString().contains("Price")) {
                lifestyle_price = view.getTag().toString();
            }
            Log.v("FOCUS", mealz + "");
        } else if (view.isFocusable() == false) {
            view.setBackgroundResource(R.drawable.circle);
            view.setFocusable(true);
            if (view.getTag().toString().contains("Category")) {
                category = null;
            } else if (view.getTag().toString().contains("Price")) {
                lifestyle_price = null;
            }


        }


    }

    public void fun__green_dot(View view) {
        if (view.getBackground().getCurrent().equals(getDrawable(R.drawable.circle))) {
            view.setBackgroundResource(R.drawable.green_dot);
        } else if (view.getBackground().getCurrent().equals(getDrawable(R.drawable.green_dot))) {
            view.setBackgroundResource(R.drawable.circle);

        }

    }

    public void food_photo(View view) {
        food_pic = true;
        Intent x = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(x,1);


    }

    protected void onActivityResult(int rc, int resc, Intent data) {
        if (food_pic == true) {
            ImageView image = null;
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            image = (ImageView) findViewById(R.id.food_pic);
            image.setBackgroundResource(0);
            image.setImageBitmap(bitmap);
            current = bitmap;
            food_pic = false;
        } else if (lifestyle_pic == true) {
            ImageView image = null;
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            image = (ImageView) findViewById(R.id.lifestyle_pic);
            image.setBackgroundResource(0);
            image.setImageBitmap(bitmap);
            current = bitmap;
            lifestyle_pic = false;

        } else if (fun_pic == true) {
            ImageView image = null;
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            image = (ImageView) findViewById(R.id.venue_pic);
            image.setBackgroundResource(0);
            image.setImageBitmap(bitmap);
            current = bitmap;
            lifestyle_pic = false;
        }

    }

    public void life_photo(View view) {
        lifestyle_pic = true;
        Intent x = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(x,1);

    }

    public void fun_photo(View view) {
        fun_pic = true;
        Intent x = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(x,1);

    }


}

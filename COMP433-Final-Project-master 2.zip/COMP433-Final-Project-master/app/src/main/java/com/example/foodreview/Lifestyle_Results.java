package com.example.foodreview;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class Lifestyle_Results extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.top_life);
    }

    public void life_r_back(View view) {
        Intent x = new Intent(this, Lifestyle.class);
        startActivity(x);
    }

    public void adv_life(View view) {
        setContentView(R.layout.adv_life_search);
    }

    public void adv_life_back(View view) {
        setContentView(R.layout.top_life);
    }
}

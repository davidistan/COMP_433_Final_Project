package com.example.foodreview;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void thrillz(View view) {
        Intent x = new Intent(this, M2.class);
        startActivity(x);
    }

    public void review(View view) {
        setContentView(R.layout.reviews_homepage);
    }

    public void back_home(View view) {
        setContentView(R.layout.activity_main);
    }

    public void food_review(View view) {
        setContentView(R.layout.food_review);
    }

    public void lifestyle_review(View view) {
        setContentView(R.layout.lifestyle_review);
    }

    public void entertainment_review(View view) {
        setContentView(R.layout.entertainment_review);
    }

    public void food_review_back(View view) {
        setContentView(R.layout.reviews_homepage);
    }

    public void lifestyle_review_back(View view) {
        setContentView(R.layout.reviews_homepage);
    }

    public void entertainment_review_back(View view) {
        setContentView(R.layout.reviews_homepage);
    }

    public void food_yellow_star(View view) {
        if (view.getTag().toString() != "yellow") {
            view.setBackgroundResource(R.drawable.yellow_star);
            view.setTag("yellow");
        } else if (view.getTag().toString() == "yellow") {
            view.setBackgroundResource(R.drawable.star);
            view.setTag("white");

        }


    }

    public void lifestyle_yellow_star(View view) {
        if (view.getTag().toString() != "yellow") {
            view.setBackgroundResource(R.drawable.yellow_star);
            view.setTag("yellow");
        } else if (view.getTag().toString() == "yellow") {
            view.setBackgroundResource(R.drawable.star);
            view.setTag("white");

        }

    }

    public void fun_yellow_star(View view) {
        if (view.getTag().toString() != "yellow") {
            view.setBackgroundResource(R.drawable.yellow_star);
            view.setTag("yellow");
        } else if (view.getTag().toString() == "yellow") {
            view.setBackgroundResource(R.drawable.star);
            view.setTag("white");

        }

    }

    public void food_green_dot(View view) {
        if (view.getTag().toString() != "green") {
            view.setBackgroundResource(R.drawable.green_dot);
            view.setTag("green");
        } else if (view.getTag().toString() == "green") {
            view.setBackgroundResource(R.drawable.circle);
            view.setTag("white");

        }

    }

    public void lifestyle_green_dot(View view) {
        if (view.getTag().toString() != "green") {
            view.setBackgroundResource(R.drawable.green_dot);
            view.setTag("green");
        } else if (view.getTag().toString() == "green") {
            view.setBackgroundResource(R.drawable.circle);
            view.setTag("white");

        }

    }

    public void fun__green_dot(View view) {
        if (view.getTag().toString() != "green") {
            view.setBackgroundResource(R.drawable.green_dot);
            view.setTag("green");
        } else if (view.getTag().toString() == "green") {
            view.setBackgroundResource(R.drawable.circle);
            view.setTag("white");

        }

    }









}
